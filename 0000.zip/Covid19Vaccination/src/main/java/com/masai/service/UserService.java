package com.masai.service;

import com.masai.model.User;

public interface UserService {
	
	public User saveUser(User user);
}
