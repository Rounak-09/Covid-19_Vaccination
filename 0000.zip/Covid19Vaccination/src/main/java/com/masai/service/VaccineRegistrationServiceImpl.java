package com.masai.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.masai.model.VaccineRegistration;
import com.masai.repository.VaccineRegistrationDao;

public class VaccineRegistrationServiceImpl implements VaccineRegistrationService{
	@Autowired
	private VaccineRegistrationDao vrDao;
	

	@Override
	public VaccineRegistration saveVRDetails(VaccineRegistration vr) {
		// TODO Auto-generated method stub
		
		
		return vrDao.save(vr);
	}

}
