package com.masai.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.masai.model.VaccineRegistration;
import com.masai.service.VaccineRegistrationServiceImpl;

public class VaccineRegistrationController {
	@Autowired
    private VaccineRegistrationServiceImpl  vrs;
	
	@PostMapping("/userdetails")
	public ResponseEntity<VaccineRegistration> saveUserDetails(  @RequestBody VaccineRegistration vr){
	        VaccineRegistration savedUserDetails = vrs.saveVRDetails(vr);
	        return new ResponseEntity<VaccineRegistration>(savedUserDetails,HttpStatus.CREATED);
	}
	
    
    
}
