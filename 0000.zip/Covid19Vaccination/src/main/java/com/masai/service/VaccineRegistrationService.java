package com.masai.service;

import com.masai.model.VaccineRegistration;

public interface VaccineRegistrationService {
	public VaccineRegistration saveVRDetails(VaccineRegistration vr);

}
